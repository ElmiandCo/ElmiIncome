# ELMI Income — Phase One

Production-oriented Next.js + TypeScript + Tailwind foundation for the ELMI Income financial intelligence portal.

## Included
- ELMI AI 5-second cinematic portal intro
- Responsive Day/Night design system
- Supabase email/password + Google authentication
- Protected application routes
- Money dashboard, income streams, expenses, calendar, opportunities, learn, settings
- Google Calendar OAuth architecture with read/create/update-ready Calendar scope
- E*TRADE placeholder with launch notification UI
- Supabase migration with RLS for ELMI Income data
- Vercel-ready Next.js app

## Supabase
Use the existing **SecureApp** project for Phase One. Apply `supabase/migrations/001_elmi_income.sql` before using financial persistence.

Do not put the Supabase service role key in the browser or commit it.

## Environment
Copy `.env.example` to `.env.local` and populate secrets.

Google Calendar requires a Google Cloud OAuth client with the redirect URI matching `GOOGLE_REDIRECT_URI`. Configure the production callback URL after deployment.

## Important production security note
The migration stores the Google refresh token in Supabase. Before production launch, encrypt refresh tokens at rest with a server-only key (the app already reserves `GOOGLE_TOKEN_ENCRYPTION_KEY` for this boundary) and keep calendar token access server-side. Do not expose refresh tokens to client components.

## Run
npm install
npm run dev

## Build
npm run build
npm start

### Google Calendar behavior
The app uses a separate Google Calendar OAuth connection (not the sign-in token) with the `calendar.events` scope, which permits reading plus creating/updating calendar events. OAuth state is random, short-lived and cookie-bound to reduce CSRF risk. Refresh tokens are encrypted server-side with AES-256-GCM before storage.

### Investment notifications
The E*TRADE card is intentionally non-functional for account access. Clicking it opens a Coming Soon modal and the notification request is persisted per signed-in user.
