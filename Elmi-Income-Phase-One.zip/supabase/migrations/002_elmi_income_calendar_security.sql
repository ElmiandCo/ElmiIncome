alter table public.elmi_income_google_connections add column if not exists encrypted_refresh_token text;
update public.elmi_income_google_connections set encrypted_refresh_token=refresh_token where encrypted_refresh_token is null and refresh_token is not null;
alter table public.elmi_income_google_connections alter column encrypted_refresh_token set not null;
alter table public.elmi_income_google_connections drop column if exists refresh_token;
