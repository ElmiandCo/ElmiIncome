import {NextResponse} from "next/server";import {beginGoogleCalendar} from "@/lib/google";
export async function GET(request:Request){const url=await beginGoogleCalendar();if(!url)return NextResponse.redirect(new URL("/sign-in",request.url));return NextResponse.redirect(url)}
