import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata={title:"ELMI Income — Financial Intelligence",description:"Your financial command center."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
